<?php

namespace App\Modules\Gxc\Controllers;


class IndexController extends ControllerBase
{

    public function indexAction()
    {

    }


}

