<?php

namespace App\Modules\Frontend\Controllers;


use Box\Spout\Common\Type;
use Box\Spout\Reader\ReaderFactory;

class IndexController extends ControllerBase
{

    public function indexAction()
    {


    }


    public function excelAction()
    {
        $this->view->disable();
        $reader=ReaderFactory::create(Type::XLSX);
        $filename=getcwd().'/files/test.xlsx';
        $reader->open($filename);
        foreach ($reader->getSheetIterator() as $sheet) {
            foreach ($sheet->getRowIterator() as $row) {
                var_dump($row);
            }
        }

    }

    public function phpinfoAction(){
        $this->view->disable();
        phpinfo();
    }

}

