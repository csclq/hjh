<?php
require '../app/bootstrap_web.php';
require_once '../vendor/autoload.php';